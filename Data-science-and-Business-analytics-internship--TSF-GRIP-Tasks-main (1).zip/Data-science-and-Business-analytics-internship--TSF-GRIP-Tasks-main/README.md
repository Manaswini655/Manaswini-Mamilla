# Data-science-and-Business-analytics-internship--TSF-GRIP-Tasks
TSF-GRIP-Task-1

Author : THATHA SRILAXMI

Task : Prediction of marks obtained by student using number of hours of study
This code contains the solution for the task of predicting the marks obtained by the student using the number of hours of study. In this task, the dataset is first explored to view the correlation between the 2 variables in the dataset and a linear regression model is fitted with the dataset which is then used for predicting the score obtained for a particular hours spent in studying by the student.


TSF-GRIP-Task-2

Author:THATHA SRILAXMI

Task : Prediction of Optimum number of clusters for the Iris Dataset
This code contains the solution for the prediction of the optimum number of clusters for the observation in the Iris Dataset and shows a visual example of the clustering of the dataset.


TSF-GRIP-TASK-5

Author: THATHA SRILAXMI

TASK:Perform exploratory data analysis on data set -INDIAN PREMIER LEAGUE
This code contains the solution to find out most successful teams,players,and factors contributing to wIn or loss of a team
